# live_server
live_server is a light-weight http server for client-side website project.
